export interface MockOptions {
    useCleanCache?: boolean;
    warnOnReplace?: boolean;
    warnOnUnregistered?: boolean;
}
export declare function enable(opts: MockOptions): void;
export declare function disable(): void;
export declare function resetCache(): void;
export declare function warnOnReplace(enable: boolean): void;
export declare function warnOnUnregistered(enable: boolean): void;
export declare function registerMock(mod: string, mock: any): void;
export declare function deregisterMock(mod: string): void;
export declare function deregisterAll(): void;
export declare function registerAllowable(mod: string): void;
export declare function registerAllowables(mods: string[]): void;
export declare function deregisterAllowable(mod: string): void;
export declare function deregisterAllowables(mods: any): void;
