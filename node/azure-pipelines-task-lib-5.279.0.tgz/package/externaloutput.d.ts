/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
import stream = require('stream');
/** Commands allowed by default once VSO commands are enabled for a path. */
export declare const defaultAllowedVsoCommands: readonly string[];
/**
 * Where the external output originates. Used for documentation and telemetry only; it does
 * NOT select an automatic allowlist. A task must explicitly enable VSO commands when needed.
 */
export type ExternalOutputSource = 'remote' | 'childProcess' | 'repository';
export interface ExternalOutputOptions {
    /** Origin of the output. Documentation/telemetry only. */
    source: ExternalOutputSource;
    /**
     * When false or omitted, every "##vso[" marker is blocked. When true, markers whose
     * command name is in the effective allowlist pass through unchanged.
     */
    enableVsoCommands?: boolean;
    /**
     * The allowlist of "area.event" command names to permit when enableVsoCommands is true.
     * Replaces (does not extend) the default list. An explicit empty array allows nothing.
     * Has no effect when enableVsoCommands is false.
     */
    allowedVsoCommands?: readonly string[];
    /** Destination for filtered output. Defaults to process.stdout. */
    destination?: NodeJS.WritableStream;
}
/**
 * Stateful, byte-level marker filter. Feed bytes with push() and finish with flush().
 * Retains only the minimal bytes needed to resolve a marker that straddles a chunk
 * boundary, so memory stays bounded regardless of input size.
 */
export declare class MarkerFilter {
    private readonly enabled;
    private readonly allowed;
    private pending;
    constructor(enabled: boolean, allowed: Set<string>);
    push(chunk: Buffer): Buffer;
    flush(): Buffer;
}
/**
 * A Transform stream that neutralizes VSO command markers in external output. Pipe untrusted
 * output into it; it writes filtered bytes to its readable side (and, via
 * createExternalOutputStream, on to the destination).
 */
export declare class ExternalOutputStream extends stream.Transform {
    private readonly markerFilter;
    constructor(options: ExternalOutputOptions);
    _transform(chunk: any, _encoding: string, callback: (error?: Error | null) => void): void;
    _flush(callback: (error?: Error | null) => void): void;
}
/**
 * Creates a filtering stream for external output and pipes it to the destination
 * (default process.stdout). Pipe untrusted output into the returned stream, e.g.
 * `jenkinsResponse.pipe(tl.createExternalOutputStream({ source: 'remote' }))`.
 */
export declare function createExternalOutputStream(options: ExternalOutputOptions): ExternalOutputStream;
/**
 * Filters a complete piece of external output and writes it to the destination
 * (default process.stdout). Each call is self-contained; for output that arrives in
 * chunks that may split a marker, use createExternalOutputStream instead.
 */
export declare function writeExternalOutput(data: string | Buffer, options: ExternalOutputOptions): void;
/** Filters one complete value and returns its bytes without writing them. */
export declare function filterExternalOutput(data: string | Buffer, options: ExternalOutputOptions): Buffer;
export interface FilteredWriter {
    write(data: string | Buffer): void;
    end(): void;
}
/** Creates a stateful writer that filters markers split across writes. */
export declare function createFilteredWriter(options: ExternalOutputOptions, destination: NodeJS.WritableStream): FilteredWriter;
