"use strict";
// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.createFilteredWriter = exports.filterExternalOutput = exports.writeExternalOutput = exports.createExternalOutputStream = exports.ExternalOutputStream = exports.MarkerFilter = exports.defaultAllowedVsoCommands = void 0;
var stream = require("stream");
//
// External output filtering.
//
// Azure Pipelines treats a task's stdout both as log text and as a command channel:
// a line containing the marker "##vso[area.event ...]data" is parsed and executed by the
// agent. When a task echoes output that originates from an untrusted source (a remote
// server, a child process, a repository filename, compiler/test output, ...), that source
// can smuggle a "##vso[" marker and make the agent run a command on its behalf.
//
// This module neutralizes markers in such external output before it reaches the agent's
// command parser. By default every marker is blocked (rewritten "##vso[" -> "##_vso[").
// A task may opt a compatibility-sensitive path into a small, explicit allowlist of
// command names; unknown, malformed, or future commands stay blocked.
//
// The filter works on raw bytes (Buffer) so it never corrupts invalid UTF-8, binary
// output, or multibyte characters split across chunk boundaries. It matches the marker
// byte-for-byte, mirroring the agent's Ordinal comparison, so the two agree exactly on
// what a marker is.
//
/** The exact marker bytes the agent recognizes as the start of a command: "##vso[". */
var MARKER = Buffer.from('##vso[', 'ascii');
/** Neutralized form written in place of a blocked marker: "##_vso[". */
var NEUTRALIZED = Buffer.from('##_vso[', 'ascii');
var EMPTY = Buffer.alloc(0);
var SPACE = 0x20;
var RBRACKET = 0x5D; // ]
var CR = 0x0D;
var LF = 0x0A;
// Maximum command-name bytes retained while waiting for a terminator.
var MAX_HEADER = 256;
/** Commands allowed by default once VSO commands are enabled for a path. */
exports.defaultAllowedVsoCommands = Object.freeze(['task.debug', 'task.setprogress']);
function resolveAllowed(options) {
    if (!options.enableVsoCommands) {
        return new Set();
    }
    var list = options.allowedVsoCommands !== undefined
        ? options.allowedVsoCommands
        : exports.defaultAllowedVsoCommands;
    // Command-name comparison is case-insensitive to match the agent's command lookup.
    return new Set(list.map(function (c) { return c.toLowerCase(); }));
}
/**
 * Normalizes a raw command-name token to the agent's canonical "area.event" form, or null
 * when it is not a valid command name. Mirrors the agent's Split('.', RemoveEmptyEntries)
 * with a required length of exactly two non-empty segments.
 */
function canonicalCommandName(raw) {
    var parts = raw.split('.').filter(function (p) { return p.length > 0; });
    if (parts.length !== 2) {
        return null;
    }
    return (parts[0] + '.' + parts[1]).toLowerCase();
}
/** Returns the longest suffix of buf that is a proper marker prefix. */
function partialMarkerSuffixLength(buf) {
    var max = Math.min(MARKER.length - 1, buf.length);
    for (var k = max; k >= 1; k--) {
        if (buf.compare(MARKER, 0, k, buf.length - k, buf.length) === 0) {
            return k;
        }
    }
    return 0;
}
/**
 * Locates the end of a command-name header that starts at `start` (the byte after a marker).
 * The name ends at the first space or ']'. A CR or LF is also reported as a terminator with
 * newline=true so the caller can fail closed. Scans at most MAX_HEADER bytes; term is -1 when
 * no terminator is found within that bound (or before the buffer ends).
 */
function scanHeader(buf, start) {
    var limit = Math.min(buf.length, start + MAX_HEADER);
    for (var k = start; k < limit; k++) {
        var b = buf[k];
        if (b === SPACE || b === RBRACKET) {
            return { term: k, newline: false };
        }
        if (b === CR || b === LF) {
            return { term: k, newline: true };
        }
    }
    return { term: -1, newline: false };
}
/**
 * Stateful, byte-level marker filter. Feed bytes with push() and finish with flush().
 * Retains only the minimal bytes needed to resolve a marker that straddles a chunk
 * boundary, so memory stays bounded regardless of input size.
 */
var MarkerFilter = /** @class */ (function () {
    function MarkerFilter(enabled, allowed) {
        this.enabled = enabled;
        this.allowed = allowed;
        this.pending = EMPTY;
    }
    MarkerFilter.prototype.push = function (chunk) {
        var buf = this.pending.length ? Buffer.concat([this.pending, chunk]) : chunk;
        this.pending = EMPTY;
        var out = [];
        var pos = 0;
        while (pos < buf.length) {
            var idx = buf.indexOf(MARKER, pos);
            if (idx === -1) {
                // No complete marker remains. Retain a possible partial marker at the tail so
                // it can be completed by the next chunk; emit everything before it.
                var keep = Math.min(partialMarkerSuffixLength(buf), buf.length - pos);
                var emitEnd = buf.length - keep;
                if (emitEnd > pos) {
                    out.push(pos === 0 && emitEnd === buf.length ? buf : buf.subarray(pos, emitEnd));
                }
                this.pending = keep ? buf.subarray(buf.length - keep) : EMPTY;
                break;
            }
            if (idx > pos) {
                out.push(buf.subarray(pos, idx));
            }
            var afterMarker = idx + MARKER.length;
            if (!this.enabled) {
                out.push(NEUTRALIZED);
                pos = afterMarker;
                continue;
            }
            // Enabled: read the command name (up to the first space or ']') and allow the marker
            // only when that name is allowlisted.
            var _a = scanHeader(buf, afterMarker), term = _a.term, newline = _a.newline;
            if (term === -1) {
                if (buf.length - afterMarker >= MAX_HEADER) {
                    // No terminator within the bound: fail closed.
                    out.push(NEUTRALIZED);
                    pos = afterMarker;
                    continue;
                }
                // Header may complete in a later chunk; retain from the marker start.
                this.pending = buf.subarray(idx);
                break;
            }
            // A CR/LF before the terminator means the agent (which parses per line) would never
            // treat this as a command, so we fail closed and neutralize.
            if (newline) {
                out.push(NEUTRALIZED);
                pos = afterMarker;
                continue;
            }
            var name_1 = canonicalCommandName(buf.toString('utf8', afterMarker, term));
            // Allowlisted markers pass unchanged; the header/data after them flow through as
            // ordinary bytes and any later markers are evaluated independently.
            out.push(name_1 && this.allowed.has(name_1) ? MARKER : NEUTRALIZED);
            pos = afterMarker;
        }
        if (out.length === 0) {
            return EMPTY;
        }
        if (out.length === 1) {
            var only = out[0];
            // Never expose module-level buffers that callers could mutate globally.
            return only === NEUTRALIZED || only === MARKER ? Buffer.from(only) : only;
        }
        return Buffer.concat(out);
    };
    MarkerFilter.prototype.flush = function () {
        var p = this.pending;
        this.pending = EMPTY;
        if (p.length === 0) {
            return EMPTY;
        }
        // An incomplete command candidate that begins with the full marker is neutralized.
        if (this.enabled && p.length >= MARKER.length && p.subarray(0, MARKER.length).equals(MARKER)) {
            return Buffer.concat([NEUTRALIZED, p.subarray(MARKER.length)]);
        }
        // A partial marker (fewer than the full bytes) cannot be executed by the agent, so it
        // is safe to emit unchanged.
        return p;
    };
    return MarkerFilter;
}());
exports.MarkerFilter = MarkerFilter;
/**
 * A Transform stream that neutralizes VSO command markers in external output. Pipe untrusted
 * output into it; it writes filtered bytes to its readable side (and, via
 * createExternalOutputStream, on to the destination).
 */
var ExternalOutputStream = /** @class */ (function (_super) {
    __extends(ExternalOutputStream, _super);
    function ExternalOutputStream(options) {
        var _this = _super.call(this) || this;
        _this.markerFilter = new MarkerFilter(!!options.enableVsoCommands, resolveAllowed(options));
        return _this;
    }
    ExternalOutputStream.prototype._transform = function (chunk, _encoding, callback) {
        try {
            var buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk), 'utf8');
            var out = this.markerFilter.push(buf);
            if (out.length) {
                this.push(out);
            }
            callback();
        }
        catch (err) {
            // Fail closed: never recover by emitting the original marker.
            callback(err);
        }
    };
    ExternalOutputStream.prototype._flush = function (callback) {
        try {
            var out = this.markerFilter.flush();
            if (out.length) {
                this.push(out);
            }
            callback();
        }
        catch (err) {
            callback(err);
        }
    };
    return ExternalOutputStream;
}(stream.Transform));
exports.ExternalOutputStream = ExternalOutputStream;
/**
 * Creates a filtering stream for external output and pipes it to the destination
 * (default process.stdout). Pipe untrusted output into the returned stream, e.g.
 * `jenkinsResponse.pipe(tl.createExternalOutputStream({ source: 'remote' }))`.
 */
function createExternalOutputStream(options) {
    var filterStream = new ExternalOutputStream(options);
    var destination = options.destination || process.stdout;
    // Do not end the shared destination (e.g. process.stdout) when the source ends.
    filterStream.pipe(destination, { end: false });
    return filterStream;
}
exports.createExternalOutputStream = createExternalOutputStream;
/**
 * Filters a complete piece of external output and writes it to the destination
 * (default process.stdout). Each call is self-contained; for output that arrives in
 * chunks that may split a marker, use createExternalOutputStream instead.
 */
function writeExternalOutput(data, options) {
    var destination = options.destination || process.stdout;
    destination.write(filterExternalOutput(data, options));
}
exports.writeExternalOutput = writeExternalOutput;
/** Filters one complete value and returns its bytes without writing them. */
function filterExternalOutput(data, options) {
    var filter = new MarkerFilter(!!options.enableVsoCommands, resolveAllowed(options));
    var buf = Buffer.isBuffer(data) ? data : Buffer.from(String(data), 'utf8');
    var filtered = filter.push(buf);
    var pending = filter.flush();
    return pending.length ? Buffer.concat([filtered, pending]) : filtered;
}
exports.filterExternalOutput = filterExternalOutput;
/** Creates a stateful writer that filters markers split across writes. */
function createFilteredWriter(options, destination) {
    var filter = new MarkerFilter(!!options.enableVsoCommands, resolveAllowed(options));
    var ended = false;
    return {
        write: function (data) {
            if (ended) {
                throw new Error('Cannot write after end');
            }
            var buf = Buffer.isBuffer(data) ? data : Buffer.from(String(data), 'utf8');
            var filtered = filter.push(buf);
            if (filtered.length) {
                destination.write(filtered);
            }
        },
        end: function () {
            if (ended) {
                return;
            }
            ended = true;
            var pending = filter.flush();
            if (pending.length) {
                destination.write(pending);
            }
        }
    };
}
exports.createFilteredWriter = createFilteredWriter;
